import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {SearchInputComponent} from './search-input/search-input.component';
import {UsersListComponent} from './users-list/users-list.component';

const routes: Routes = [
  {path:'search_input', component : SearchInputComponent},
  {path:'', component : UsersListComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
