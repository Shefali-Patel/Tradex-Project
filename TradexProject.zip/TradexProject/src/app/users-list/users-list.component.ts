import { Component, OnInit } from '@angular/core';
import { HttpClient } from "@angular/common/http";
@Component({
  selector: 'app-users-list',
  templateUrl: './users-list.component.html',
  styleUrls: ['./users-list.component.css']
})
export class UsersListComponent implements OnInit {

  private data:any = []
  constructor(private http: HttpClient) { }

  ngOnInit(): void {
  }

  getData(val:string){
    console.log(val);
    const url ='https://jsonplaceholder.typicode.com/users';
    this.http.get(url).subscribe((list)=>{

      console.log(list);
      this.data = list;
      console.log(this.data)
    })
  }

}
